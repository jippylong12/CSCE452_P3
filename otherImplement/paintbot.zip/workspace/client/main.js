window.game = new Phaser.Game(1000, 800, Phaser.AUTO, 'phaser-example', { preload: preload, create: create, update: update, render: render });
window.socket = null;

init();

function init() {
	var socket = io.connect();
	window.socket = socket;
	setEventHandlers();
	socket.emit("set ID");
};

var DH_enum = Object.freeze({
    THETA : 0,
    D     : 1,
    A     : 2,
    ALPHA : 3
});

// Defined offset variables
var buttonSize   = 33;
var buttonOffset = 10;
var panelOffset  = 10;
var KeyHeight    = 14;

//The height of the base joint
var baseHeight   = 32;
var L1 = 150;
var L2 = 100;
var L3 = 75;

//Graphics objects
var ctlPanel;
var brushPanel;
var rbtArea;
var link1Graphic;
var link2Graphic;
var link3Graphic;
var linkGraphics;
var brushGraphic;

// Robot Joints
var link_1;
var link_2;
var link_3;
var links;

//Robot Brush
var brush;
var bmd;
var bmdDest;
var spaceKey;
var fKey;
var worldKeys;
var toggle = false;
var brushColor = '000000';

var DH_table;
var timeCheck;

//Slider Variables
var slickUI;
var slider;
var panel;
var btnpanel;
var delayGraphic;
var brushDiameter = 20;

//PROJECT 3 GLOBALS
//Client number (1 = master)
var client_num = 0;
//Determines whether input is delayed or not
var delay = false;

function preload() {
    game.stage.scale.pageAlignHorizontally = true;
    
    game.load.spritesheet('button_left', 'Assets/left_arrow.png');
    game.load.spritesheet('button_right', 'Assets/right_arrow.png');
    game.load.spritesheet('button_down', 'Assets/down_arrow.png');
    game.load.spritesheet('button_up', 'Assets/up_arrow.png');
    game.load.image('base_link', 'Assets/base_link.png');
    game.load.image('paint', 'Assets/PaintButton.png');
    slickUI = game.plugins.add(Phaser.Plugin.SlickUI);
    slickUI.load('Assets/ui/kenney/kenney.json'); // Use the path to your kenney.json. This is the file that defines your theme.
    
    game.add.plugin(Fabrique.Plugins.InputField);
}

function create() {
    
    var style  = { font: "14px Arial", fill: "#FFFFFF", align: "center", stroke: "#000000",  strokeThickness: 3 }; 
    var style1 = { font: "14px Arial", fill: "#00FF00", align: "center", stroke: "#000000",  strokeThickness: 3 }; 
    var style2 = { font: "14px Arial", fill: "#FF0000", align: "center", stroke: "#000000",  strokeThickness: 3 };
    var style3 = { font: "14px Arial", fill: "#00FFFF", align: "center", stroke: "#000000",  strokeThickness: 3 };
    
    // --- Begin Control Panel Initialization
    ctlPanel = game.add.graphics(game.world.width - 125 - (panelOffset), panelOffset);
    if(client_num==1){
        ctlPanel.lineStyle(2, 0x000000, 0.5);
        ctlPanel.beginFill(0x000000, 0.4);
        ctlPanel.drawRect(0, 0, 125, 200);
        ctlPanel.endFill();
    
        game.add.text(game.world.width - 95, buttonSize + 5, "Joint 3", style3);
        game.add.text(game.world.width - 95, buttonSize * 2 + 15, "Joint 2", style2);
        game.add.text(game.world.width - 95, buttonSize * 3 + 25, "Joint 1", style1);
        // --- End Control Panel Initialization
    }
    
    // --- Begin World Control Panel Initialization
    brushPanel = game.add.graphics(game.world.width - 125 - (panelOffset), ctlPanel.bottom + 8 * KeyHeight);
    if(client_num==1){
        brushPanel.lineStyle(2, 0x000000, 0.5);
        brushPanel.beginFill(0x000000, 0.4);
        brushPanel.drawRect(0,0,125,175);
        brushPanel.endFill();
        game.add.text(brushPanel.x + panelOffset/2, brushPanel.y, "Brush Ctl. Panel", style);
        game.add.button(brushPanel.x + panelOffset, brushPanel.centerY - panelOffset/2, 'button_left', xLeft , this);
        game.add.text(brushPanel.x + 1.4*panelOffset, brushPanel.centerY - panelOffset/2 + 30, "X-", style);
        game.add.button(brushPanel.right - 4.5*panelOffset, brushPanel.centerY - panelOffset/2, 'button_right', xRight, this);
        game.add.text(brushPanel.right - 4*panelOffset, brushPanel.centerY - panelOffset/2 + 30, "X+", style);
        game.add.button(brushPanel.centerX - 1.8*panelOffset, brushPanel.top + 5*panelOffset, 'button_up', yUp, this);
        game.add.text(brushPanel.centerX - 1.8*panelOffset + 5, (brushPanel.top + (5*panelOffset - 18)), "Y+", style);
        game.add.button(brushPanel.centerX - 1.75*panelOffset, brushPanel.bottom - 6*panelOffset, 'button_down', yDown, this);
        game.add.text(brushPanel.centerX - 1.75*panelOffset + 8, (brushPanel.bottom - (6*panelOffset) + 33), "Y-", style);
    }
    
    // --- World Control Panel HotKeys Initialization
    worldKeys = game.input.keyboard.createCursorKeys();
    
    // --- End World Control Panel Initialization
		
    // --- Begin Robot Area Initialization
    rbtArea = game.add.graphics(0,0);
    rbtArea.lineStyle(2, 0x000000, 0.5);
    rbtArea.beginFill(0xFFFFFF, 0.7);
    rbtArea.drawRect(0, 0, ctlPanel.x - 2 * panelOffset, game.world.height);
    rbtArea.endFill();
    
    game.add.text(rbtArea.x + panelOffset * 2, rbtArea.y + panelOffset * 2, "Robot Area", style);
    // --- End Robot Area Initialization
    
    var btnX_left = game.world.width - ctlPanel.width - panelOffset/2;
    game.stage.backgroundColor = '#182d3b';
    
    if(client_num==1){
        game.add.text(btnX_left + panelOffset, ctlPanel.y, " Control Panel", style);

        // Create the Control Panel buttons
        game.add.button(btnX_left, buttonSize * 3 + buttonOffset * 2, 'button_left', rotate1Left, this);
        game.add.button(ctlPanel.right - panelOffset/2 - buttonSize, buttonSize * 3 + buttonOffset * 2, 'button_right', rotate1Right, this);
        game.add.button(btnX_left, buttonSize * 2 + buttonOffset, 'button_left', rotate2Left, this);
        game.add.button(ctlPanel.right - panelOffset/2 - buttonSize, buttonSize * 2 + buttonOffset, 'button_right', rotate2Right, this);
        game.add.button(btnX_left, buttonSize, 'button_left', rotate3Left, this);
        game.add.button(ctlPanel.right - panelOffset/2 - buttonSize, buttonSize, 'button_right', rotate3Right, this);
        game.add.button(btnX_left + 10, buttonSize * 4 + buttonOffset * 3, 'paint', addPaint, this);
    }
    
    //Keyboard HotKeys, More in the Update Function
    spaceKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
    spaceKey.onDown.add(setToggle, this);
    fKey = game.input.keyboard.addKey(Phaser.Keyboard.F);
    fKey.onDown.add(addPaint, this);
    
    if(client_num==1){
        game.add.text(rbtArea.right + panelOffset/2, ctlPanel.bottom + panelOffset, "Hot Keys:", style);
        game.add.text(rbtArea.right + panelOffset, ctlPanel.bottom + 2 * KeyHeight, "Q, W - Joint 3", style);
        game.add.text(rbtArea.right + panelOffset, ctlPanel.bottom + 3 * KeyHeight, "A, S  - Joint 2", style);
        game.add.text(rbtArea.right + panelOffset, ctlPanel.bottom + 4 * KeyHeight, "Z, X  - Joint 1", style);
        game.add.text(rbtArea.right + panelOffset, ctlPanel.bottom + 5 * KeyHeight, "F  - Paint", style);
        game.add.text(rbtArea.right + panelOffset, ctlPanel.bottom + 6 * KeyHeight, "Space  - Toggle Paint", style);
    }
    
    //Graphics for each link
    link1Graphic = game.add.graphics(0,0);
    link2Graphic = game.add.graphics(0,0);
    link3Graphic = game.add.graphics(0,0);
    linkGraphics = [link3Graphic, link2Graphic, link1Graphic];
    
    //Graphic for paintbrush
    brushGraphic = game.add.graphics(0,0);
    
    //BMD for the paint drops
    bmd = game.make.bitmapData(game.width, game.height);
    bmdDest = game.make.bitmapData(game.width, game.height);
    bmdDest.addToWorld();
    
    // Link offset is around 4px
    game.add.sprite((rbtArea.width - rbtArea.x)/2 - 4, game.world.height - baseHeight, 'base_link');
   
    var topLeft1 = {x: (rbtArea.width - rbtArea.x)/2, y: game.world.height - 150 - baseHeight};
    var topRight1 = {x: topLeft1.x + 24, y: topLeft1.y};
    var bottomLeft1 = {x: topLeft1.x, y: topLeft1.y + 150};
    var bottomRight1 = {x: bottomLeft1.x + 24, y: topRight1.y + 150};
    
    var topLeft2 = {x: (rbtArea.width - rbtArea.x)/2, y: game.world.height - 250 - baseHeight};
    var topRight2 = {x: topLeft2.x + 24, y: topLeft2.y};
    var bottomLeft2 = {x: topLeft2.x, y: topLeft2.y + 100};
    var bottomRight2 = {x: bottomLeft2.x + 24, y: topRight2.y + 100};
    
    var topLeft3 = {x: (rbtArea.width - rbtArea.x)/2, y: game.world.height - 325 - baseHeight};
    var topRight3 = {x: topLeft3.x + 24, y: topLeft3.y};
    var bottomLeft3 = {x: topLeft3.x, y: topLeft3.y + 75};
    var bottomRight3 = {x: bottomLeft3.x + 24, y: topRight3.y + 75};
    
    link_1 = new Phaser.Polygon([new Phaser.Point(topLeft1.x, topLeft1.y), new Phaser.Point(topRight1.x, topRight1.y),  new Phaser.Point(bottomRight1.x, bottomRight1.y), new Phaser.Point(bottomLeft1.x, bottomLeft1.y)]);
    link1Graphic.beginFill(0x00FF00);
    link1Graphic.drawPolygon(link_1);
    link1Graphic.endFill();
    link_1.topLeft = topLeft1;
    link_1.topRight = topRight1;
    link_1.bottomRight = bottomRight1;
    link_1.bottomLeft = bottomLeft1;
    link_1.originX = (link_1.bottomLeft.x + link_1.bottomRight.x)/2;
    link_1.originY = link_1.bottomLeft.y;
    
    link_2 = new Phaser.Polygon([new Phaser.Point(topLeft2.x, topLeft2.y), new Phaser.Point(topRight2.x, topRight2.y),  new Phaser.Point(bottomRight2.x, bottomRight2.y), new Phaser.Point(bottomLeft2.x, bottomLeft2.y)]);
    link2Graphic.beginFill(0xFF0000);
    link2Graphic.drawPolygon(link_2);
    link2Graphic.endFill();
    link_2.topLeft = topLeft2;
    link_2.topRight = topRight2;
    link_2.bottomRight = bottomRight2;
    link_2.bottomLeft = bottomLeft2;
    link_2.originX = (link_2.bottomLeft.x + link_2.bottomRight.x)/2;
    link_2.originY = link_2.bottomLeft.y;
    
    link_3 = new Phaser.Polygon([new Phaser.Point(topLeft3.x, topLeft3.y), new Phaser.Point(topRight3.x, topRight3.y),  new Phaser.Point(bottomRight3.x, bottomRight3.y), new Phaser.Point(bottomLeft3.x, bottomLeft3.y)]);
    link3Graphic.beginFill(0x00FFFF);
    link3Graphic.drawPolygon(link_3);
    link3Graphic.endFill();
    link_3.topLeft = topLeft3;
    link_3.topRight = topRight3;
    link_3.bottomRight = bottomRight3;
    link_3.bottomLeft = bottomLeft3;
    link_3.originX = (link_3.bottomLeft.x + link_3.bottomRight.x)/2;
    link_3.originY = link_3.bottomLeft.y;
    
    //Reverse order, so if we're on the top link we only use links[0].
    links = [link_3, link_2, link_1];
    
    //Create Paintbrush circle
    brush = new Phaser.Circle((topLeft3.x+topRight3.x)/2, (topLeft3.y + topRight3.y)/2, 20);
    brushGraphic.beginFill(brushColor);
    brushGraphic.drawCircle(brush.x, brush.y, 20);
    brushGraphic.endFill();
    
    DH_table = createDH(3);
    DH_table[1][DH_enum.A] = L1; // Joint1 = 150px
    DH_table[2][DH_enum.A] = L2; // Joint2 = 100px
    DH_table[3][DH_enum.A] = L3; // Joint3 = 75px
    
    timeCheck = game.time.now;
    
    // --- Begin Paint Brush Size Slider
    
    if(client_num==1){
        slickUI.add(panel = new SlickUI.Element.Panel(game.world.width - 125 - (panelOffset), brushPanel.bottom + .5*KeyHeight, 125, 60));
        panel.add(slider = new SlickUI.Element.Slider(10,10, panel.width - 32));
        var valueText = new SlickUI.Element.Text(0,panel.height - 20, 'Brush: 20');
        panel.add(valueText).centerHorizontally();
        slider.onDrag.add(function (value) {
            brushDiameter = Math.round(value * 20);
            valueText.value = 'Brush: ' + Math.round(value * 20);
            valueText.centerHorizontally();
            brushGraphic.clear();
            brush.setTo((link_3.topLeft.x + link_3.topRight.x) / 2, (link_3.topLeft.y + link_3.topRight.y)/2, Math.round(value * 20));
            brushGraphic.beginFill(brushColor);
            brushGraphic.drawCircle(brush.x, brush.y, Math.round(value * 20));
            brushGraphic.endFill();
        });
    }
    
    // --- End Paint Brush Size Slider
    
    // --- Begin Change Paint Color Button
    if(client_num==1){
        var changePaintBtn = game.add.graphics(panel.x+15, panel.y+panel.height+25);
        changePaintBtn.lineStyle(2, 0x000000, 0.5);
    	changePaintBtn.beginFill(0x000000, 0.4);
    	changePaintBtn.drawRect(0, 0, 100, 25);
    	changePaintBtn.endFill();
    	changePaintBtn.inputEnabled = true;
    	changePaintBtn.events.onInputDown.add(function() {
    		changePaintBtn.inputEnabled = false;
    		
    		// Create the input box for the player to change their name
    		var input = game.add.inputField(game.world.centerX-7, game.world.centerY-75, {
    			font: '18px Arial',
    			fill: '#212121',
    			fontWeight: 'bold',
    			width: 125,
    			padding: 8,
    			borderWidth: 1,
    			borderColor: '#000',
    			borderRadius: 6,
    			placeHolder: brushColor
    		});
    		input.startFocus(); // Immediately sets focus to input box
    		
    		// Create the submit button to change their name
    		var submitBtn = game.add.graphics(0, 0);
    		submitBtn.lineStyle(2, 0x000000, 0.5);
    		submitBtn.beginFill(0x000000, 0.4);
    		submitBtn.drawRect(game.world.centerX+input.width/8-5, game.world.centerY-25, 100, 30);
    		submitBtn.endFill();
    		submitBtn.inputEnabled = true;
    		submitBtn.events.onInputDown.add(function() {
    			if (input.value.length > 0) {
    				console.log("Pressed submit - new color will be: " + input.value);
    				brushColor = input.value;
    				brushGraphic.clear();
    				brushGraphic.beginFill(brushColor);
                    brushGraphic.drawCircle(brush.x, brush.y, brushDiameter);
                    brushGraphic.endFill();
    			}
    			changePaintBtn.inputEnabled = true;
    			input.destroy();
    			submitText.destroy();
    			submitBtn.destroy();				
    		});
    		var style = {font: "14px Arial", fill: "#FFFFFF", align: "center", fontWeight: "bold"};
    		var submitText = game.add.text(game.world.centerX+submitBtn.width/2-10, game.world.centerY-submitBtn.height/2, "Submit", style);
    		
    	}, this);
	
	    var style = {font: "14px Arial", fill: "#FFFFFF", wordWrap: true, wordWrapWidth: changePaintBtn.width, align: "center"};
	    var changeNameText = game.add.text(changePaintBtn.centerX - 35, changePaintBtn.y + 5, "Paint Color", style);
    }
	// --- End Change Color Button
	
	// --- Begin SetDelay Button
    //slickUI.add(btnpanel = new SlickUI.Element.Panel(game.world.width - 125 - (panelOffset), changePaintBtn.bottom + 10, 125, 40));
    //if(client_num==1){
        
        slickUI.add(btnpanel = new SlickUI.Element.Panel(game.world.width - 125 - (panelOffset), game.world.height - 180, 125, 40));
        delayGraphic = game.add.graphics(btnpanel.x,btnpanel.y);
        var btnText = new SlickUI.Element.Text(0,0, 'Delay');
        btnpanel.add(button = new SlickUI.Element.Button(0,0, 140, 80)).events.onInputUp.add(function () {
            if(delay == false){
                delayGraphic.clear();
                delayGraphic.alpha = .60;
                delayGraphic.beginFill("0x00FF00");
                delayGraphic.drawRoundedRect(0,0,125,40,8);
                delayGraphic.endFill();
                delay = true;
            }
            else {
                delayGraphic.clear();
                delayGraphic.alpha = .60;
                delayGraphic.beginFill("0xFF0000");
                delayGraphic.drawRoundedRect(0,0,125,40,8);
                delayGraphic.endFill();
                delay = false;
            }
            
            socket.emit("set Delay", delay);
        });
        btnpanel.add(btnText).center();
        delayGraphic.alpha = .60;
        delayGraphic.beginFill("0xFF0000");
        delayGraphic.drawRoundedRect(0,0,125,40,8);
        delayGraphic.endFill();
    //}
    // --- End SetDelay Button
	socket.emit("new client");
}

function setEventHandlers() {
	socket.on("connect", this.onSocketConnected);
	socket.on("set ID", this.onSetID);
	socket.on("set Delay", this.onSetDelay);
	socket.on("disconnect", this.onSocketDisconnect);
	socket.on("move", this.onMove);
	socket.on("paint", this.onPaint);
}

function onSetID(data){
    client_num = data;
}

function onSetDelay(){
    if(delay == false){
        delayGraphic.clear();
        delayGraphic.alpha = .60;
        delayGraphic.beginFill("0x00FF00");
        delayGraphic.drawRoundedRect(0,0,125,40,8);
        delayGraphic.endFill();
        delay = true;
    }
    else {
        delayGraphic.clear();
        delayGraphic.alpha = .60;
        delayGraphic.beginFill("0xFF0000");
        delayGraphic.drawRoundedRect(0,0,125,40,8);
        delayGraphic.endFill();
        delay = false;
    }
}

function onSocketConnected() {
	console.log("Connected to socket server");
}

function onSocketDisconnect() {
	console.log("Disconnected from socket server");
}

async function onMove(data) {
	if (data.L1topLeftX == 0) {
		console.log("Server needs initial setup...");
		socket.emit("move", {L1topLeftX: link_1.topLeft.x, L1topLeftY: link_1.topLeft.y, 
		L1topRightX: link_1.topRight.x, L1topRightY: link_1.topRight.y, L1bottomLeftX: link_1.bottomLeft.x, 
		L1bottomLeftY: link_1.bottomLeft.y, L1bottomRightX: link_1.bottomRight.x, L1bottomRightY: link_1.bottomRight.y,
		L2topLeftX: link_2.topLeft.x, L2topLeftY: link_2.topLeft.y, 
		L2topRightX: link_2.topRight.x, L2topRightY: link_2.topRight.y, L2bottomLeftX: link_2.bottomLeft.x, 
		L2bottomLeftY: link_2.bottomLeft.y, L2bottomRightX: link_2.bottomRight.x, L2bottomRightY: link_2.bottomRight.y,
		L3topLeftX: link_3.topLeft.x, L3topLeftY: link_3.topLeft.y, 
		L3topRightX: link_3.topRight.x, L3topRightY: link_3.topRight.y, L3bottomLeftX: link_3.bottomLeft.x, 
		L3bottomLeftY: link_3.bottomLeft.y, L3bottomRightX: link_3.bottomRight.x, L3bottomRightY: link_3.bottomRight.y});
	} else {
	    //If we are in delay mode, don't move for 2 seconds on the slaves
        if(delay && client_num!=1){
	        await sleep(2000);
	    }
		link_1.topLeft.x = data.L1topLeftX;
		link_1.topLeft.y = data.L1topLeftY;
		link_1.topRight.x = data.L1topRightX;
		link_1.topRight.y = data.L1topRightY;
		link_1.bottomLeft.x = data.L1bottomLeftX;
		link_1.bottomLeft.y = data.L1bottomLeftY;
		link_1.bottomRight.x = data.L1bottomRightX;
		link_1.bottomRight.y = data.L1bottomRightY;
		link_2.topLeft.x = data.L2topLeftX;
		link_2.topLeft.y = data.L2topLeftY;
		link_2.topRight.x = data.L2topRightX;
		link_2.topRight.y = data.L2topRightY;
		link_2.bottomLeft.x = data.L2bottomLeftX;
		link_2.bottomLeft.y = data.L2bottomLeftY;
		link_2.bottomRight.x = data.L2bottomRightX;
		link_2.bottomRight.y = data.L2bottomRightY;
		link_3.topLeft.x = data.L3topLeftX;
		link_3.topLeft.y = data.L3topLeftY;
		link_3.topRight.x = data.L3topRightX;
		link_3.topRight.y = data.L3topRightY;
		link_3.bottomLeft.x = data.L3bottomLeftX;
		link_3.bottomLeft.y = data.L3bottomLeftY;
		link_3.bottomRight.x = data.L3bottomRightX;
		link_3.bottomRight.y = data.L3bottomRightY;
		var colors = [ 0x00FFFF, 0xFF0000, 0x00FF00 ];
		for (var i = links.length-1; i >= 0; i--) {
			console.log("i: " + i);
			var currentGraphic = linkGraphics[i];
			var current_link = links[i];
			currentGraphic.clear();
			current_link.setTo(current_link.topLeft, current_link.topRight, current_link.bottomRight, current_link.bottomLeft);
			currentGraphic.beginFill(colors[i]);
			currentGraphic.drawPolygon(current_link);
			currentGraphic.endFill();
		}
		brushGraphic.clear();
		brush.setTo((link_3.topLeft.x + link_3.topRight.x) / 2, (link_3.topLeft.y + link_3.topRight.y)/2, brushDiameter);
		brushGraphic.beginFill(brushColor);
		brushGraphic.drawCircle(brush.x, brush.y, brushDiameter);
		brushGraphic.endFill();
	}
	console.log("Moved.");
}

async function onPaint(data) {
    //If we are in delay mode, don't paint for 2 seconds on the slaves
    if(delay && client_num!=1){
	    await sleep(2000);
	}
    bmd.circle(data.x,data.y,data.size,data.color);
}

function createPointVector(link, x, y){
    var PointVector = [];
    for(var i = 0; i<3; i++){
        PointVector[i] = [];
    }
    PointVector[0][0] = x-link.originX;
    PointVector[1][0] = link.originY-y;
    PointVector[2][0] = 0;
    return PointVector;
}

function rotateLink(link, angle){
    var current_link;
    var originX = link.originX;
    var originY = link.originY;
    angle = toRadians(angle);
    var starting_link = 1;
    if(link == link_2)
        starting_link = 2;
    else if(link == link_1)
        starting_link = 3;
    //For link 3, we move only the top link, link 2 = top 2, link 3 = all links
    var color;
    for(var link_num = starting_link; link_num>0; link_num--){
        current_link = links[link_num-1];
        //Set the appropriate color depending on the link and correct origins for turning
        if(current_link == link_3) {
            color = 0x00FFFF;
			current_link.originX = (link_2.topLeft.x + link_2.topRight.x)/2;
			current_link.originY = (link_2.topLeft.y + link_2.topRight.y)/2;
        } else if(current_link == link_2) {
            color = 0xFF0000;
			current_link.originX = (link_1.topLeft.x + link_1.topRight.x)/2;
			current_link.originY = (link_1.topLeft.y + link_1.topRight.y)/2;
        } else
            color = 0x00FF00;
            
        //For each of the 4 corners, calculate the point vector and use the rotation matrix to get the new point vector
        for(var i = 0; i < 4; i++){
            var PointVector = createPointVector(link, current_link.points[i].x, current_link.points[i].y);
            //if(current_link == link_3)
            //   console.log("Link 3 PointVector: (" + PointVector[0][0] + "," + PointVector[1][0] + ")");
            //Changed to -angle 
            var RotationMatrix = new Phaser.Matrix(Math.cos(-angle), -Math.sin(-angle), Math.sin(-angle), Math.cos(-angle), 0, 0);
            var temp;
            //Top-Left corner 
            if(i == 0){
                temp = new Phaser.Point((RotationMatrix.a*PointVector[0][0] + RotationMatrix.b*PointVector[1][0] + RotationMatrix.tx*PointVector[2][0]), 
                                        (RotationMatrix.c*PointVector[0][0]+ RotationMatrix.d*PointVector[1][0] + RotationMatrix.ty*PointVector[2][0]));
                temp.x = temp.x + originX;
                temp.y = originY - temp.y;
                current_link.topLeft = new Phaser.Point(temp.x, temp.y);
            }
            //Top-Right corner
            else if(i == 1){
                temp = new Phaser.Point((RotationMatrix.a*PointVector[0][0] + RotationMatrix.b*PointVector[1][0] + RotationMatrix.tx*PointVector[2][0]), 
                                        (RotationMatrix.c*PointVector[0][0]+ RotationMatrix.d*PointVector[1][0] + RotationMatrix.ty*PointVector[2][0]));
                temp.x = temp.x + originX;
                temp.y = originY - temp.y;
                current_link.topRight = new Phaser.Point(temp.x, temp.y);
            }
            //Bottom-Right corner
            else if(i == 2){
                temp = new Phaser.Point((RotationMatrix.a*PointVector[0][0] + RotationMatrix.b*PointVector[1][0] + RotationMatrix.tx*PointVector[2][0]), 
                                        (RotationMatrix.c*PointVector[0][0]+ RotationMatrix.d*PointVector[1][0] + RotationMatrix.ty*PointVector[2][0]));
                temp.x = temp.x + originX;
                temp.y = originY - temp.y; 
                current_link.bottomRight = new Phaser.Point(temp.x, temp.y);
            }
            //Bottom-Left corner
            else{
                temp = new Phaser.Point((RotationMatrix.a*PointVector[0][0] + RotationMatrix.b*PointVector[1][0] + RotationMatrix.tx*PointVector[2][0]), 
                                        (RotationMatrix.c*PointVector[0][0]+ RotationMatrix.d*PointVector[1][0] + RotationMatrix.ty*PointVector[2][0]));
                temp.x = temp.x + originX;
                temp.y = originY - temp.y;
                current_link.bottomLeft = new Phaser.Point(temp.x, temp.y);
            }
        }
        //Remove the old link from the screen
        var currentGraphic = linkGraphics[link_num-1];
        currentGraphic.clear();
        //Update the link's position and redraw it
        current_link.setTo(current_link.topLeft, current_link.topRight, current_link.bottomRight, current_link.bottomLeft);
        currentGraphic.beginFill(color);
        currentGraphic.drawPolygon(current_link);
        currentGraphic.endFill();
    }
    //Update brush
    brushGraphic.clear();
    brush.setTo((link_3.topLeft.x + link_3.topRight.x) / 2, (link_3.topLeft.y + link_3.topRight.y)/2, brushDiameter);
    brushGraphic.beginFill(brushColor);
    brushGraphic.drawCircle(brush.x, brush.y, brushDiameter);
    brushGraphic.endFill();

    //If we are in delay mode, don't emit "move" for 2 seconds
	socket.emit("move", {L1topLeftX: link_1.topLeft.x, L1topLeftY: link_1.topLeft.y, 
		L1topRightX: link_1.topRight.x, L1topRightY: link_1.topRight.y, L1bottomLeftX: link_1.bottomLeft.x, 
		L1bottomLeftY: link_1.bottomLeft.y, L1bottomRightX: link_1.bottomRight.x, L1bottomRightY: link_1.bottomRight.y,
		L2topLeftX: link_2.topLeft.x, L2topLeftY: link_2.topLeft.y, 
		L2topRightX: link_2.topRight.x, L2topRightY: link_2.topRight.y, L2bottomLeftX: link_2.bottomLeft.x, 
		L2bottomLeftY: link_2.bottomLeft.y, L2bottomRightX: link_2.bottomRight.x, L2bottomRightY: link_2.bottomRight.y,
		L3topLeftX: link_3.topLeft.x, L3topLeftY: link_3.topLeft.y, 
		L3topRightX: link_3.topRight.x, L3topRightY: link_3.topRight.y, L3bottomLeftX: link_3.bottomLeft.x, 
		L3bottomLeftY: link_3.bottomLeft.y, L3bottomRightX: link_3.bottomRight.x, L3bottomRightY: link_3.bottomRight.y});
}

//http://stackoverflow.com/questions/951021/what-is-the-javascript-version-of-sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// theta, d, a, alpha
function createDH(joints) {
    var DH = [];
    for (var i = 0; i <= joints; i++) {
        DH[i] = [0, 0, 0, 0];
    }
    DH[1][DH_enum.THETA] = 90;
    return DH;
}

function toDegrees(angle) {
    return angle * (180 / Math.PI);
}

function toRadians(angle) {
    return angle * (Math.PI / 180);
}

function multiplyMatrix(A, B) {
    var result = [];
    
    for (var i = 0; i < A.length; i++) {
        result[i] = [];
        for (var j = 0; j < B[0].length; j++) {
            result[i][j] = 0;
        }
    }
    
    if (A[0].length != B.length) {
        console.log("Error: A rows must match B cols.");
    }
    
    for (var i = 0; i < A.length; i++) {
        for (var j = 0; j < B[0].length; j++) {
            for (var k = 0; k < A[0].length; k++) {
                result[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    return result;
}

// Returns the inverse of matrix A
// Reference: http://stackoverflow.com/questions/17428587/transposing-a-2d-array-in-javascript
function inverseMatrix(A) {
    var result = A[0].map(function(col, i) {
        return A.map(function(row) {
            return row[i]
        })
    });
    
    return result;
}

function printDH() {
    for (var i = 0; i < DH_table.length; i++) {
        console.log(DH_table[i][DH_enum.THETA] + ' ' + DH_table[i][DH_enum.D] + ' ' + DH_table[i][DH_enum.A] + ' ' + DH_table[i][DH_enum.ALPHA]);
    }
}

function rotate1Right() {
    if(link_3.topRight.y < game.world.height && link_3.bottomRight.y < game.world.height &&
            link_1.topRight.y < game.world.height && link_2.bottomRight.y < game.world.height &&
            link_2.bottomLeft.y < game.world.height && link_2.topRight.y < game.world.height){
        rotateLink(link_1, 1);
        DH_table[1][DH_enum.THETA]++;
    }
}

function rotate1Left() {
    if(link_3.topLeft.y < game.world.height && link_3.bottomLeft.y < game.world.height &&
            link_1.topLeft.y < game.world.height && link_2.bottomRight.y < game.world.height &&
            link_2.bottomLeft.y < game.world.height && link_2.topLeft.y < game.world.height) {
        rotateLink(link_1, -1);
        DH_table[1][DH_enum.THETA]--; 
    }

}

function rotate2Right() {
    if(link_2.topRight.y < game.world.height && link_3.topRight.y < game.world.height &&
            link_3.bottomLeft.y < game.world.height && link_3.bottomRight.y < game.world.height){
        rotateLink(link_2, 1);
        DH_table[2][DH_enum.THETA]++;
    }
}

function rotate2Left() {
    if(link_2.topLeft.y < game.world.height && link_3.topLeft.y < game.world.height &&
            link_3.bottomLeft.y < game.world.height && link_3.bottomRight.y < game.world.height){
        rotateLink(link_2, -1);
        DH_table[2][DH_enum.THETA]--;
    }

}

function rotate3Right() {
    if(link_3.topRight.y < game.world.height) {
        rotateLink(link_3, 1);
        DH_table[3][DH_enum.THETA]++;
    }

}

function rotate3Left() {
    if(link_3.topLeft.y < game.world.height) {
        rotateLink(link_3, -1);
        DH_table[3][DH_enum.THETA]--;
    }
}

function inverseKine(x, y){
    var realX = x-links[2].originX;
    var realY = links[2].originY-y;
    //console.log("realX: " + realX + " realY: " + realY);
    var theta1, theta2, theta3;
    var phi, alpha, delta = 0;
    var Px, Py, realPx, realPy, LP;
	var r = Math.sqrt(Math.pow(realX,2) + Math.pow(realY,2));
	
	// If out of range
	if (r > (L1 + L2 + L3) || r < (L1 - L2 + L3)) {
		theta1 = toDegrees(Math.atan2(realY, realX));
	} else {
		if (Math.abs(r - L1) < L2 - L3) {
			delta = Math.ceil(toDegrees(Math.acos((2*Math.pow(L1,2) - Math.pow(L2 - L3, 2))/(2*L1*L1))));
		}
		theta1 = toDegrees(Math.atan2(realY, realX)) - delta;
		//console.log("Theta1: " + theta1);
		Px = -L1*Math.cos(toRadians(theta1));
		Py = L1*Math.sin(toRadians(theta1));
		//console.log("Px: " + Px + " Py: " + Py);
		LP = Math.sqrt(Math.pow(realX-Px,2) + Math.pow(realY-Py,2));
		//console.log("LP: " + LP);
		theta3 = 180-toDegrees(Math.acos((Math.pow(LP,2)-Math.pow(L2,2)-Math.pow(L3,2))/(-2*L2*L3)));
		//console.log("Theta3: " + theta3);
		phi = toDegrees(Math.acos((Math.pow(L3,2)-Math.pow(L2,2)-Math.pow(LP,2))/(-2*L2*LP)));
		//console.log("Phi: " + phi);
		alpha = toDegrees(Math.acos((Math.pow(realX,2)+Math.pow(realY,2)-Math.pow(L1,2)-Math.pow(LP,2))/(-2*L1*LP)));
		//console.log("Alpha: " + alpha);
		theta2 = alpha - 180 - phi;
		//console.log("Theta2: " + theta2);
		if(realX >= 0){
			theta3*=-1;
			theta2*=-1;
		}
		if(!Number.isNaN(theta1) && !Number.isNaN(theta2) && !Number.isNaN(theta3)){
            // Rotate our links
            rotateLink(link_1, theta1 - DH_table[1][DH_enum.THETA]);
            rotateLink(link_2, theta2 - DH_table[2][DH_enum.THETA]);
            rotateLink(link_3, theta3 - DH_table[3][DH_enum.THETA]);
            // Update our thetas / make sure DH_table[1][DH_enum.THETA] is initialized to 90 originally
            DH_table[1][DH_enum.THETA] = theta1;
            DH_table[2][DH_enum.THETA] = theta2;
            DH_table[3][DH_enum.THETA] = theta3;
        }
	}
}

function xRight() {
    inverseKine((brush.x + 5), brush.y);
}

function xLeft() {
    inverseKine((brush.x - 5), brush.y);
}

function yUp() {
    inverseKine(brush.x, (brush.y - 5));
}

function yDown() {
    inverseKine(brush.x, (brush.y + 5));
}

//Adds a drop of paint where the brush is at
function addPaint() {
    var rgb = Phaser.Color.hexToColor(brushColor);
    var strColor = 'rgb(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ')';
    bmd.circle(brush.x,brush.y,brushDiameter/2,strColor);
	socket.emit("paint", {color: strColor, size: brushDiameter/2, x: brush.x, y: brush.y});
}

// This is implemented simply to delay the movement speed so its not too quick
function wait() {
    timeCheck = game.time.now;
}

//Sets the paint toggle to on or off.
function setToggle() {
    if (toggle == true) {
        toggle = false;
       
    }
    else {
        toggle = true;
    }

}

function update(){
    
    if (game.time.now - timeCheck > 100 && client_num==1) {
        if (game.input.keyboard.isDown(Phaser.Keyboard.Q)) {
            rotate3Left();
            wait();
        } else if (game.input.keyboard.isDown(Phaser.Keyboard.W)) {
            rotate3Right();
            wait();
        } else if (game.input.keyboard.isDown(Phaser.Keyboard.A)) {
            rotate2Left();
            wait();
        } else if (game.input.keyboard.isDown(Phaser.Keyboard.S)) {
            rotate2Right();
            wait();
        } else if (game.input.keyboard.isDown(Phaser.Keyboard.Z)) {
            rotate1Left();
            wait();
        } else if (game.input.keyboard.isDown(Phaser.Keyboard.X)) {
            rotate1Right();
            wait();
        } else if (worldKeys.left.isDown) {
            xLeft();
            wait();
        } else if (worldKeys.right.isDown) {
            xRight();
            wait();
        } else if (worldKeys.down.isDown) {
            yDown();
            wait();
        } else if (worldKeys.up.isDown) {
            yUp();
            wait();
        }
        if (fKey.isDown){
            addPaint();
            wait();
        }
    }
    if (toggle && client_num==1){
        addPaint();
    }
    
    bmdDest.copy(bmd,0,0);
    game.world.bringToTop(link1Graphic);
    game.world.bringToTop(link2Graphic);
    game.world.bringToTop(link3Graphic);
    game.world.bringToTop(brushGraphic);
}

function render(){ }
