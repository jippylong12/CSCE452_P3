# CSCE452-PaintBot
Project 3 for CSCE 452 - Server/Client PaintBot

#Team Members
Name Adams, Will
email: redskinguy12@tamu.edu

Name Kutsch, Joshua
email: jkcoolsville@tamu.edu

Name McClain, Sean
email: smcclain@tamu.edu

#Compiling

Run ```'npm install'``` inside of the root directory. <br />
To run, use the command 'node server.js' inside of the root directory. <br />

#Requirements
- Uses Socket.IO, Express, Node.JS, and Phaser.IO