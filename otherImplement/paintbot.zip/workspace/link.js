// TopLeft(x1,y1)		TopRight(x2,y2)
// BottomLeft(x3,y3)	BottomRight(x4,y4)
var Link = function(number, x1, y1, x2, y2, x3, y3, x4, y4) {
	this.number = number;
	this.topLeft = {x: x1, y: y1};
	this.topRight = {x: x2, y: y2};
	this.bottomLeft = {x: x3, y: y3};
	this.bottomRight = {x: x4, y: y4};
};

module.exports = Link;