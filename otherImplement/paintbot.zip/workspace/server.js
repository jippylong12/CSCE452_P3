// Server is hosted on port 30001.
// In order for this to be run, you must first run `npm install`.
var express = require("express");
var app = express();
var http = require("http");
var server = http.createServer(app);
var io = require("socket.io").listen(server);
var Link = require("./link");
var Paint = require("./paint");
var client_num = 0;
var delay = false;

app.use(express.static("client"));

//var socket = server.listen(30001); <-- Use this when running locally
var socket = server.listen(process.env.PORT, process.env.IP);
var links;			// Our links array
var paintspots;		// Our paint spots array

init();

// Initializes our 3 links with 0's as the default coordinates.
// First client connected will send us the default coordinates so we can update it.
function init() {
	var Link1 = new Link(1, 0, 0, 0, 0, 0, 0, 0, 0);
	var Link2 = new Link(2, 0, 0, 0, 0, 0, 0, 0, 0);
	var Link3 = new Link(3, 0, 0, 0, 0, 0, 0, 0, 0);
	links = [Link1, Link2, Link3];
	paintspots = [];
	setEventHandlers();
};

// Event Handlers for handling different events sent from our clients
function setEventHandlers() {
	io.on("connection", function(client) {
		console.log("New user has joined session - " + client.id);
		client.on("new client", onNewClient);
		client.on("set ID", onSetID);
		client.on("set Delay", onSetDelay);
		client.on("disconnect", onClientDisconnect);
		client.on("move", onMove);
		client.on("paint", onPaint);
		client.on("setup", onSetup);
	});
};


function onSetID(){
	this.emit("set ID", ++client_num);	
}
function onSetDelay(){
	this.broadcast.emit("set Delay");	
}
// When a new client connects, send the client what the current coordinates are for the links.
// If this is the first client, then the client will send back coordinates of the default link positions.
function onNewClient() {
	this.emit("move", {L1topLeftX: links[0].topLeft.x, L1topLeftY: links[0].topLeft.y, 
		L1topRightX: links[0].topRight.x, L1topRightY: links[0].topRight.y, L1bottomLeftX: links[0].bottomLeft.x, 
		L1bottomLeftY: links[0].bottomLeft.y, L1bottomRightX: links[0].bottomRight.x, L1bottomRightY: links[0].bottomRight.y,
		L2topLeftX: links[1].topLeft.x, L2topLeftY: links[1].topLeft.y, 
		L2topRightX: links[1].topRight.x, L2topRightY: links[1].topRight.y, L2bottomLeftX: links[1].bottomLeft.x, 
		L2bottomLeftY: links[1].bottomLeft.y, L2bottomRightX: links[1].bottomRight.x, L2bottomRightY: links[1].bottomRight.y,
		L3topLeftX: links[2].topLeft.x, L3topLeftY: links[2].topLeft.y, 
		L3topRightX: links[2].topRight.x, L3topRightY: links[2].topRight.y, L3bottomLeftX: links[2].bottomLeft.x, 
		L3bottomLeftY: links[2].bottomLeft.y, L3bottomRightX: links[2].bottomRight.x, L3bottomRightY: links[2].bottomRight.y});
		
	for (var i = 0; i < paintspots.length; i++) {
		this.emit("paint", {color: paintspots[i].color, size: paintspots[i].size, x: paintspots[i].x, y: paintspots[i].y});
	}
};

// Simply states when a client has disconnected.
function onClientDisconnect() {
	console.log("Player has disconnected." + this.id);
	--client_num;
};

// Retrieves a move emission from a client, updates our Links and then
// broadcasts the new changes to the rest of the connected clients
function onMove(data) {
	links[0].topLeft.x = data.L1topLeftX;
	links[0].topLeft.y = data.L1topLeftY;
	links[0].topRight.x = data.L1topRightX;
	links[0].topRight.y = data.L1topRightY;
	links[0].bottomLeft.x = data.L1bottomLeftX;
	links[0].bottomLeft.y = data.L1bottomLeftY;
	links[0].bottomRight.x = data.L1bottomRightX;
	links[0].bottomRight.y = data.L1bottomRightY;
	links[1].topLeft.x = data.L2topLeftX;
	links[1].topLeft.y = data.L2topLeftY;
	links[1].topRight.x = data.L2topRightX;
	links[1].topRight.y = data.L2topRightY;
	links[1].bottomLeft.x = data.L2bottomLeftX;
	links[1].bottomLeft.y = data.L2bottomLeftY;
	links[1].bottomRight.x = data.L2bottomRightX;
	links[1].bottomRight.y = data.L2bottomRightY;
	links[2].topLeft.x = data.L3topLeftX;
	links[2].topLeft.y = data.L3topLeftY;
	links[2].topRight.x = data.L3topRightX;
	links[2].topRight.y = data.L3topRightY;
	links[2].bottomLeft.x = data.L3bottomLeftX;
	links[2].bottomLeft.y = data.L3bottomLeftY;
	links[2].bottomRight.x = data.L3bottomRightX;
	links[2].bottomRight.y = data.L3bottomRightY;
	
	this.broadcast.emit("move", {L1topLeftX: links[0].topLeft.x, L1topLeftY: links[0].topLeft.y, 
		L1topRightX: links[0].topRight.x, L1topRightY: links[0].topRight.y, L1bottomLeftX: links[0].bottomLeft.x, 
		L1bottomLeftY: links[0].bottomLeft.y, L1bottomRightX: links[0].bottomRight.x, L1bottomRightY: links[0].bottomRight.y,
		L2topLeftX: links[1].topLeft.x, L2topLeftY: links[1].topLeft.y, 
		L2topRightX: links[1].topRight.x, L2topRightY: links[1].topRight.y, L2bottomLeftX: links[1].bottomLeft.x, 
		L2bottomLeftY: links[1].bottomLeft.y, L2bottomRightX: links[1].bottomRight.x, L2bottomRightY: links[1].bottomRight.y,
		L3topLeftX: links[2].topLeft.x, L3topLeftY: links[2].topLeft.y, 
		L3topRightX: links[2].topRight.x, L3topRightY: links[2].topRight.y, L3bottomLeftX: links[2].bottomLeft.x, 
		L3bottomLeftY: links[2].bottomLeft.y, L3bottomRightX: links[2].bottomRight.x, L3bottomRightY: links[2].bottomRight.y});
};

// Probably will need to keep track of all paint currently on the robot area.
// Needs to place new paint into the array and broadcast it to other clients
function onPaint(data) {
	var newPaint = new Paint(data.color, data.size, data.x, data.y);
	paintspots.push(newPaint);
	this.broadcast.emit("paint", {color: data.color, size: data.size, x: data.x, y: data.y});
};

// Setups up our initial coordinates for all links (should only be done once)
function onSetup(data) {
	console.log("Setup");
	links[0].topLeft.x = data.L1topLeftX;
	links[0].topLeft.y = data.L1topLeftY;
	links[0].topRight.x = data.L1topRightX;
	links[0].topRight.y = data.L1topRightY;
	links[0].bottomLeft.x = data.L1bottomLeftX;
	links[0].bottomLeft.y = data.L1bottomLeftY;
	links[0].bottomRight.x = data.L1bottomRightX;
	links[0].bottomRight.y = data.L1bottomRightY;
	links[1].topLeft.x = data.L2topLeftX;
	links[1].topLeft.y = data.L2topLeftY;
	links[1].topRight.x = data.L2topRightX;
	links[1].topRight.y = data.L2topRightY;
	links[1].bottomLeft.x = data.L2bottomLeftX;
	links[1].bottomLeft.y = data.L2bottomLeftY;
	links[1].bottomRight.x = data.L2bottomRightX;
	links[1].bottomRight.y = data.L2bottomRightY;
	links[2].topLeft.x = data.L3topLeftX;
	links[2].topLeft.y = data.L3topLeftY;
	links[2].topRight.x = data.L3topRightX;
	links[2].topRight.y = data.L3topRightY;
	links[2].bottomLeft.x = data.L3bottomLeftX;
	links[2].bottomLeft.y = data.L3bottomLeftY;
	links[2].bottomRight.x = data.L3bottomRightX;
	links[2].bottomRight.y = data.L3bottomRightY;
};