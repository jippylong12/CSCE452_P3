// Paint(Color, Size, X, Y)
var Paint = function(Color, Size, X, Y) {
	this.color = Color;
	this.size = Size;
	this.x = X;
	this.y = Y;
};

module.exports = Paint;